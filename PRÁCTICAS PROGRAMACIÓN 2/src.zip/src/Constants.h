// DNI1 45931406 REYES ALBILLAR, ALEJANDRO
// DNI2 74245842 PASCUAL GOMEZ, ALEJANDRO

#include <iostream>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <cstring>
using namespace std;

#ifndef CONSTANTS_H_
#define CONSTANTS_H_

const int kTITLE=30;
const int kARTIST=60;
const int kALBUM=60;
const int kGENRE=30;
const int kURL=255;
const string kERROR="Error: Unknown option";



#endif /* CONSTANTS_H_ */
