#ifndef P2TESTSUITE_H_
#define P2TESTSUITE_H_

#include <stdlib.h>
#include <string.h>

#include <cxxtest/TestSuite.h>

using namespace std;

#include "../src/Song.h"
#include "../src/Collection.h"
#include "../src/Playlist.h"
#include "../src/Utils.h"
#include "../src/Player.h"
#include "../src/Constants.h"

// funciones auxiliares

string rtrim(string s)
{
  unsigned int ls=s.length();
  
  while (ls>0 && s[ls-1] == ' ') ls--;
  
  return s.substr(0,ls);
}

bool CmpRTrim(string a,string b)
{
  //  compara dos string ignorando los blancos que pueda haber al final de 
  // cada cadena
  
  string am = rtrim(a),
         bm = rtrim(b);
  
  return am == bm;  
}


// No se comprueba nada de Player, ya que esta clase se proporciona
// con los materiales


class SongTestSuite : public CxxTest::TestSuite 
{
  public:
    void setUp() { }
    
    void tearDown() { }
    
    void testSong() {  

     // constructor por defecto
     Song s1;
     TS_ASSERT_EQUALS(s1.getTitle().length(), 0);
     
     // constructor con argumentos
     Song s2(1,"La Playa","Pepe","Verano Indio","Classic","http://www.misCanciones.org/Pepe/La_Playa");
     TS_ASSERT_EQUALS(s2.getId(), 1);
     TS_ASSERT_EQUALS(s2.getTitle(), "La Playa");
     TS_ASSERT_EQUALS(s2.getArtist(), "Pepe");
     TS_ASSERT_EQUALS(s2.getAlbum(), "Verano Indio");
     TS_ASSERT_EQUALS(s2.getGenre(), "Classic");
     TS_ASSERT_EQUALS(s2.getUrl(), "http://www.misCanciones.org/Pepe/La_Playa");

     // constructor con cadena JSON
     string strJSON = "{\"wrapperType\":\"track\", \"kind\":\"song\", \"artistId\":136975, \"collectionId\":401151866, \"trackId\":401151904, \"artistName\":\"The Beatles\", \"collectionName\":\"Let It Be\", \"trackName\":\"Let It Be\", \"collectionCensoredName\":\"Let It Be\", \"trackCensoredName\":\"Let It Be\", \"artistViewUrl\":\"https://itunes.apple.com/us/artist/the-beatles/id136975?uo=4\", \"collectionViewUrl\":\"https://itunes.apple.com/us/album/let-it-be/id401151866?i=401151904&uo=4\", \"trackViewUrl\":\"https://itunes.apple.com/us/album/let-it-be/id401151866?i=401151904&uo=4\", \"previewUrl\":\"http://a106.phobos.apple.com/us/r1000/055/Music/v4/fa/9f/2a/fa9f2ae7-a237-7899-7401-b9df497a6c00/mzaf_2208415321484927286.m4a\", \"artworkUrl30\":\"http://a2.mzstatic.com/us/r30/Music/23/f0/1a/mzi.ojxbpuxu.30x30-50.jpg\", \"artworkUrl60\":\"http://a1.mzstatic.com/us/r30/Music/23/f0/1a/mzi.ojxbpuxu.60x60-50.jpg\", \"artworkUrl100\":\"http://a3.mzstatic.com/us/r30/Music/23/f0/1a/mzi.ojxbpuxu.100x100-75.jpg\", \"collectionPrice\":12.99, \"trackPrice\":1.29, \"releaseDate\":\"1970-05-08T07:00:00Z\", \"collectionExplicitness\":\"notExplicit\", \"trackExplicitness\":\"notExplicit\", \"discCount\":1, \"discNumber\":1, \"trackCount\":12, \"trackNumber\":6, \"trackTimeMillis\":243027, \"country\":\"USA\", \"currency\":\"USD\", \"primaryGenreName\":\"Rock\", \"radioStationUrl\":\"https://itunes.apple.com/us/station/idra.401151904\"},";
     Song s3(strJSON);
     TS_ASSERT_EQUALS(s3.getTitle(), "Let It Be");
     TS_ASSERT_EQUALS(s3.getArtist(), "The Beatles");
     TS_ASSERT_EQUALS(s3.getAlbum(), "Let It Be");
     TS_ASSERT_EQUALS(s3.getGenre(), "Rock");
     TS_ASSERT_EQUALS(s3.getUrl(), "http://a106.phobos.apple.com/us/r1000/055/Music/v4/fa/9f/2a/fa9f2ae7-a237-7899-7401-b9df497a6c00/mzaf_2208415321484927286.m4a");

     // Setter
     s3.setId(2);
     TS_ASSERT_EQUALS(s3.getId(),2);

     s3.setTitle( s2.getTitle() );
     TS_ASSERT_EQUALS(s3.getTitle(), s2.getTitle() );
     s3.setArtist( s2.getArtist());
     TS_ASSERT_EQUALS(s3.getArtist(), s2.getArtist());
     s3.setAlbum( s2.getAlbum() );
     TS_ASSERT_EQUALS(s3.getAlbum(), s2.getAlbum());
     s3.setGenre( s2.getGenre() );
     TS_ASSERT_EQUALS(s3.getGenre(), s2.getGenre());
     s3.setUrl(s2.getUrl());
     TS_ASSERT_EQUALS(s3.getUrl(), s2.getUrl());

     
     // Operador de salida
     stringstream ss;
     ss << s3;
     string s=ss.str();
     TS_ASSERT_EQUALS(!s.compare("2 | La Playa | Pepe | Verano Indio | Classic\n") || 
                      !s.compare("2 | La Playa | Pepe | Verano Indio | Classic"),true );

     // Operador de entrada
     istringstream iss("La voz\n\n\nGenero\n\n");
     iss >> s1;
     TS_ASSERT_EQUALS(s1.getTitle(),"La voz");

    // constructor con SongBin y toBinary
	
    SongBin sb = s3.toBinary();
    Song s4(sb);
    stringstream ss1;
    ss1 << s4;
    TS_ASSERT_EQUALS(ss1.str().compare("2 | La Playa | Pepe | Verano Indio | Classic\n") ||
			  ss1.str().compare("2 | La Playa | Pepe | Verano Indio | Classic"), 1 );

    // printPlaylist: lo comprobaremos con Playlist::print() pero comprobamos su definicion aqui

    s4.printPlaylist();

    // printXSPF: lo comprobaremos con Playlist::saveXSPF() pero comprobamos su definicion aqui

    ofstream f;
    s4.printXSPF(f);

    // isEqual
    TS_ASSERT_EQUALS(s3.isEqual(s4),true);

   }

};

class CollectionTestSuite : public CxxTest::TestSuite 
{
  public:
    void setUp() { }
    
    void tearDown() { }
    
    void testCollection() {  

	// Constructor por defecto
	
	Collection col;
	Playlist pl(&col);


	// read && Utils::loadData

	TS_ASSERT(Utils::loadData(col,pl));

	//	Song getSongAt(int) const;
	
	Song sg = col.getSongAt(19);
	stringstream ss;
	ss << sg;
	string s=ss.str();
	TS_ASSERT_EQUALS(!s.compare("20 | One World | Dire Straits | Brothers In Arms | Rock\n") ||
			  !s.compare("20 | One World | Dire Straits | Brothers In Arms | Rock"),true );

	// int size() const;
	TS_ASSERT_EQUALS(col.size(),109);

	// 	bool addSong();
	TS_ASSERT_EQUALS(col.addSong(),false); // entrada-testAC.txt: Anyade One World (Dire Straits), repetido
	TS_ASSERT_EQUALS(col.addSong(),true);  // entrada-testAC.txt: Anyade La Playa (Pepe), nuevo

	//	int findIdSong(int) const;

	TS_ASSERT_EQUALS(col.findIdSong(110),109);
	
	//	bool isSongInCollection(Song) const;

	TS_ASSERT_EQUALS(col.isSongInCollection(sg),true);

	// bool show() const;

	TS_ASSERT_EQUALS(col.show(),false); // la comprobacion con true se hace con deleteSong	y con editSong
	                                  // entrada-testAC.txt: Busca xxxx, debe devolver false

	// 	void deleteSong();
	col.deleteSong(); // entrada-testAC.txt: busca "", luego selecciona la cancion 120 (no existe)
	TS_ASSERT_EQUALS(col.size(), 110);
	col.deleteSong(); // entrada-testAC.txt: busca "", luego selecciona la cancion 110 y pulsa 'y' (no deberia borrarse porque no es 'Y')
	TS_ASSERT_EQUALS(col.size(), 110);
	col.deleteSong(); // entrada-testAC.txt: busca "", luego selecciona la cancion 110 y pulsa 'Y' (se borra)

	//	void editSong();

	Song songAux=col.getSongAt(98);
	col.editSong();  // entrada-testAC.txt: selecciona todas las canciones, edita número 99, opcion 6 (incorrecta), luego opcion 1 (title) con valor xxxx
	col.editSong();  // entrada-testAC.txt: selecciona todas las canciones, edita número 99, opcion 2 (artist) con valor xxxx
	col.editSong();  // entrada-testAC.txt: selecciona todas las canciones, edita número 99, opcion 3 (album) con valor xxxx
	col.editSong();  // entrada-testAC.txt: selecciona todas las canciones, edita número 99, opcion 4 (genre) con valor xxxx
	col.editSong();  // entrada-testAC.txt: selecciona todas las canciones, edita número 99, opcion 5 (url) con valor xxxx
	// entrada-testAC.txt: q para volver al menu principal
	// Comprobamos cambios hechos con editSong:
	TS_ASSERT_EQUALS(col.getSongAt(98).getTitle(),"xxxx");
	TS_ASSERT_EQUALS(col.getSongAt(98).getArtist(),"xxxx");
	TS_ASSERT_EQUALS(col.getSongAt(98).getGenre(),"xxxx");
	TS_ASSERT_EQUALS(col.getSongAt(98).getAlbum(),"xxxx");
	TS_ASSERT_EQUALS(col.getSongAt(98).getUrl(),"xxxx");
	// Prueba de setters, copia de SongAux (restauramos valores editados)
	col.getSongAt(98).setTitle(songAux.getTitle());	
	col.getSongAt(98).setArtist(songAux.getArtist());	
	col.getSongAt(98).setGenre(songAux.getGenre());	
	col.getSongAt(98).setAlbum(songAux.getAlbum());	
	col.getSongAt(98).setUrl(songAux.getUrl());	
	
	//	bool importJSON(string);

	TS_ASSERT_EQUALS(col.importJSON("entrada/beatles.txt"),true); // Apertura de beatles.txt
	TS_ASSERT_EQUALS(col.getSongAt(col.findIdSong(124)).getTitle(),"Dear Prudence");

	//	void clear();

	col.clear(); // Se vacia la coleccion
	TS_ASSERT_EQUALS(col.size(),0); 


	//	bool read(ifstream &) && bool write(ofstream &) const;

	Utils::loadData(col,pl); // Carga de datos de minitunes.dat
	ofstream f1("kk.dat");
	TS_ASSERT_EQUALS( col.write(f1), true ); // Prueba de escritura de collection, importante: debe devolver true
	f1.close();
	col.clear(); // Limpiamos la coleccion
	ifstream f2("kk.dat");
	TS_ASSERT_EQUALS( col.read(f2),true ); // Prueba de lectura de collection, importante: deve devolver true
	f2.close();
	system("rm kk.dat"); 
    }
};

class PlaylistTestSuite : public CxxTest::TestSuite 
{
  public:
    void setUp() { }
    
    void tearDown() { }
    
    void testPlaylist() {  

	// Constructor
	Collection col;
	Playlist pl(&col);
	TS_ASSERT_EQUALS(col.size(),0);

	// Carga de datos (ya comprobado en Collection)
	Utils::loadData(col,pl);

	//	int size() const;
	TS_ASSERT_EQUALS(pl.size(),4);

	//	void print(int) const;
	pl.print(2); // Prueba de print mostrando >
	
	//	void manage();
	pl.manage(); // entrada-testAC.txt: q para salir de la opcion, esta linea solo comprueba que existe el metodo manage

	//	void addSongs();
	pl.addSongs(); // entrada-testAC.txt: Busca "", luego anyade canciones 12 1 1 12 12 1 14
	TS_ASSERT_EQUALS(pl.size(),11); // Comprueba nuevo tamanyo del playlist

	//	void removeSongs();
	pl.removeSongs(); // entrada-testAC.txt: Elimina canciones 1,12 del playlist
	TS_ASSERT_EQUALS(pl.size(),4); 

	//	void clearSongs();
	pl.clearSongs(); // entrada-testAC.txt: opcion 'n' para no borrar las canciones
	pl.clearSongs(); // entrada-testAC.txt: opcion 'Y' para borrar las canciones
	TS_ASSERT_EQUALS(pl.size(),0);

	//	bool saveXSPF() const;
	TS_ASSERT_EQUALS(pl.saveXSPF(),false); // Error empty playlist
	
	
	//	void play() const;
	pl.play();  // Error empty playlist
	Utils::loadData(col,pl);
	pl.play(); // entrada-testAC.txt: Opcion incorrecta 'w' 
	           // entrada-testAC.txt: Opcion 's' para pasar a la siguiente cancion
	           // entrada-testAC.txt: Opcion 'p' para pausar la cancion
	           // entrada-testAC.txt: Opcion 'a' para volver a la anterior
	           // entrada-testAC.txt: Opcion 'q' para terminar la reproduccion

	//	bool read(ifstream &) && bool write(ofstream &) const;

	ofstream f1("kk.dat");
	TS_ASSERT_EQUALS( pl.write(f1), true ); // Escritura de playlist. Importante, debe devolver true
	f1.close();

	ifstream f2("kk.dat");
	TS_ASSERT_EQUALS( pl.read(f2),true ); // Lectura de playlist. Importante, debe devolver true
	f2.close();
	system("rm kk.dat");
    }
};

class UtilsTestSuite : public CxxTest::TestSuite 
{
  public:
    void setUp() { }
    
    void tearDown() { }
    
    void testUtils() { 
	
	//	static bool saveData(const Collection &collection, const Playlist &playlist);
	// Ya comprobado

	//	static bool loadData(Collection &collection, Playlist &playlist);
	// Ya comprobado

	//	static bool manageArguments(int argc, char *argv[], Collection &collection, Playlist &playlist);
	Collection col;
	Playlist pl(&col);
	char *argv[1]; 
	char *argv1[3];
	argv1[1] = strdup("-d"); argv1[2] = strdup("-i");	
	char *argv2[2];
	argv2[1]= strdup("-d");
	char *argv3[3];
	argv3[1] = strdup("-i"); argv3[2] = strdup("entrada/beatles.txt");

	TS_ASSERT_EQUALS(Utils::manageArguments(1,argv,col,pl),true); // Sin parametros
	TS_ASSERT_EQUALS(Utils::manageArguments(3,argv1,col,pl),false); // -d -i
	TS_ASSERT_EQUALS(Utils::manageArguments(2,argv2,col,pl),true); // -d
	TS_ASSERT_EQUALS(col.size(),109); // Comprobacion de cargado
	}
};

#endif /*P2TESTSUITE_H_*/
