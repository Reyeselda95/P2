#!/bin/bash

DIRPRAC=.

MAXTIME=10 	   # Tiempo máximo de ejecución (en segundos) de una prueba
PRINCIPAL=./minitunes	# Nombre del ejecutable de la práctica
ENT=$DIRPRAC/entrada	   # Directorio con los ficheros de pruebas de entrada
SAL=$DIRPRAC/salida	   # Directorio con los ficheros de salidas correctas
OBT=obtenido       # Directorio con los ficheros obtenidos tras la ejecución de la práctica
VAL="valgrind -q"  # Si valgrind no está instalado, quitar "valgrind -q" de esta linea (quedaría VAL=""). Ojo: La práctica debe probarse siempre con valgrind antes de la entrega.

npruebasa=40	 # Número de pruebas a ejecutar del autocorrector
npruebasc=8	 # Número de pruebas a ejecutar del corrector
valorpruebasa=0.025  # Valor individual de las pruebas del autocorrector
valorpruebasc=0.125  # Valor individual de las pruebas del corrector
valorpuc=6.5 # Valor total de las pruebas unitarias del corrector
valorpua=1.5 # Valor total de las pruebas unitarias del autocorrector

let npruebas=$npruebasa+$npruebasc
pok=0
nota=0

# Ficheros binarios de entrada para las pruebas
binario[25]="entrada/p25e_minitunes.dat"
binario[26]="entrada/minitunes.dat"
binario[27]="entrada/minitunes.dat"
binario[28]="entrada/minitunes.dat"
binario[29]="entrada/minitunes.dat"
binario[32]="entrada/p32e_minitunes.dat"
binario[34]="entrada/p34e_minitunes.dat"
binario[38]="entrada/p38e_minitunes.dat"
binario[39]="entrada/p39e_minitunes.dat"
binario[43]="entrada/p43e_minitunes.dat"
binario[45]="entrada/p45e_minitunes.dat"


# Argumentos de programa para las pruebas
args[28]="-d -i"
args[29]="-d"
args[30]="-i entrada/beatles.txt"
args[32]="-d"
args[33]="-i entrada/acdc.txt"
args[36]="-i entrada/ironmaiden.txt"
args[37]="-i entrada/acdc.txt"
args[38]="-d"
args[43]="-d"
args[45]="-d"
args[46]="-di"
args[47]="-i entrada/acdc.txt"


mata=$DIRPRAC/mata
comparefiles=$DIRPRAC/comparefiles
meikfail=makefile-corrector


for i in `seq 1 $npruebasa`
do
  VAL[$i]=$VALGRIND
done

# Las pruebas que escriben ficheros binarios deben hacerse sin valgrind
VAL[26]=""
VAL[35]=""
VAL[40]=""


# -------------- generar y compilar los ficheros auxiliares mata.c y comparefiles.cc -----
function genMata() {

if ! test -x mata ; then  # si ya existe no se genera
echo "#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <signal.h>

const int TAMMAXFICH=300000;
int f;int segundos,st;
int segejec=0;
char *nfsal=NULL;
void SeAcabo(int i){  
  fprintf(stderr,\"ERROR, tiempo de ejecución agotado... (%d segundos)\\n\",segundos);
  fflush(stderr); 
  kill(f,SIGKILL);  
  exit(-1); 
}
void SeAcaboFich(int i){  
  fprintf(stderr,\"ERROR, fichero de salida muy grande (cuelgue?)... \\n\");
  fflush(stderr); 
  kill(f,SIGKILL);  
  exit(-1); 
}
int FicheroGrande() {  
  struct stat s;  int ret=0;
  if (nfsal != NULL) {   
    stat(nfsal,&s);    
    if (s.st_size > TAMMAXFICH) ret = 1;  
  }  
  return ret;
}
void Control(int i){ 
  segejec++; 
  if (segejec >= segundos) SeAcabo(i); 
  else if (FicheroGrande()) SeAcaboFich(i); 
  else alarm(1); 
}
void Salir(int i){exit(1);}
int main(int argc,char *argv[]){ 
  if (argc < 4) exit(1);  
  segundos = atoi(argv[1]);  
  nfsal = argv[2]; 
  signal(SIGALRM,Control);  
  signal(SIGCHLD,Salir);  
  alarm(1);  
  if ((f = fork()) == 0) execvp(argv[3],&argv[3]);   
  else wait(&st);
}
" > mata.c
gcc -o mata mata.c
fi
}

function genComparefiles() {

if ! test -x comparefiles ; then # si ya existe no se genera
echo "#include <iostream>
#include <fstream>
#include <stdlib.h>

using namespace std;

int main(int argc, char *argv[])
{
  int salida=0;

  if (argc!=3) cout << \"Sintaxis: \" << argv[0] << \" <obtenido.txt> <correcto.txt>\" << endl;
  else 
  {
    ifstream fo(argv[1]);
    ifstream fc(argv[2]);
    if (fo.is_open() && fc.is_open())
    {
      string so,sc,tmp;

      fo >> tmp;
      while (!fo.eof() || tmp.length()!=0)
      {
        so=so+tmp;
        tmp=\"\";
        fo >> tmp;
      }
      fc >> tmp;
      while (!fc.eof() || tmp.length()!=0)
      {
        sc=sc+tmp;
        tmp=\"\";
        fc >> tmp;
      }

      // ignorar los '-' en las líneas
      string scok, sook;
      for (unsigned int i=0; i<so.length(); i++)
        if (so[i]!='-') sook=sook+so[i];
      for (unsigned int i=0; i<sc.length(); i++)
        if (sc[i]!='-') scok=scok+sc[i];
                                 
      if (sook!=scok) {
        exit(-1);
      }
    }
    else {
      cout << \"Fichero \" << argv[1] << \" o \" << argv[2] << \" no encontrado\" << endl;
      exit(-1);
    }
  }
  exit(0);
  return salida;
}
" > comparefiles.cc

g++ -o comparefiles comparefiles.cc

fi
}

echo "*********************************************************"
echo " Corrector P2 practica3 julio "


# Comprobar si está valgrind instalado
hayValgrind=$(which valgrind)
if test "$hayValgrind" == "" ; then
  echo "AVISO: El corrector se ejecutará sin valgrind, por lo que es posible que"
  echo "el resultado de la corrección no sea fiable. Para comprobar realmente que la"
  echo "práctica es correcta, debes probar el corrector en un ordenador Linux"
  echo "con valgrind instalado antes de la entrega."
  echo ""
  read -p "Pulsa [Enter] para continuar"
  for i in `seq 1 $npruebasa`
  do
    VAL[$i]=""
  done
fi


# Comprobar si es linux 32, si no mostrar advertencia de ficheros binarios
MACHINE_TYPE=`uname -s -m`
if test "$MACHINE_TYPE" != "Linux i686" ; then
  echo "AVISO: No estás ejecutando la práctica en un sistema Linux de 32 bits,"
  echo "es posible que las pruebas de ficheros binarios no funcionen correctamente."
  echo "Prueba tu práctica con el linux del laboratorio antes de entregarla."
  echo ""
  read -p "Pulsa [Enter] para continuar"
fi


#echo " Generando ficheros auxiliares... "
genMata
genComparefiles
rm -rf mata.c
rm -rf comparefiles.cc


let npruebas=$npruebasa+$npruebasc
pok=0;
nota=0


# sumar nota
function pruebaok() {

	echo "OK"
	let pok++;

	if [ $1 -le $npruebasa ]; then
		nota=`echo - | awk -v K=$nota -v M=$valorpruebasa '{printf("%.12g",K+M)}'`
	else
		nota=`echo - | awk -v K=$nota -v M=$valorpruebasc '{printf("%.12g",K+M)}'`
	fi;
}

# Compilacion
echo
echo "*********************************************************"
echo " Compilando..."
echo "*********************************************************"
rm -rf src/*.o
rm -rf $PRINCIPAL


cd src
cp ../player/Player.* .
make -f ../$meikfail 2>&1


if [ $? -ne 0 ]; then
	echo "LA PRACTICA NO COMPILA"
else

  mv minitunes ..
  cd -

  if [ "$#" -ne 0 ]
  then
  	npruebas=0
  fi


  # Ejecucion y comprobacion de la salida
  echo
  echo "*********************************************************"
  echo " Ejecutando y comprobando salida a la vez..."
  echo "*********************************************************"
 

for i in `seq 1 $npruebas`
  do

  # Copia el fichero binario
  if [ ${#binario[$i]} -ne 0 ]; then
    cp ${binario[$i]} minitunes.dat
    if [ $i -eq 25 ]; then
  	chmod -w minitunes.dat
    fi;    
  fi;

  if [ $i -eq 48 ]; then
      rm -rf minitunes.dat
  fi;


  tempfile=`mktemp /tmp/prog2iiXXXXX`

  # Ejecucion del programa
  if [ ${#args[$i]} -eq 0 ]; then
    echo "Prueba $i" 
    ./mata $MAXTIME $OBT/p${i}so.txt ${VAL[$i]} $PRINCIPAL < $ENT/p${i}e.txt > $OBT/p${i}so.txt 2> $tempfile
  else 
    echo "Prueba $i (./minitunes ${args[$i]})"
    ./mata $MAXTIME $OBT/p${i}so.txt ${VAL[$i]} $PRINCIPAL ${args[$i]} < $ENT/p${i}e.txt > $OBT/p${i}so.txt 2> $tempfile
  fi
  
  # Borra el fichero binario
  rm -rf minitunes.dat

  if test -s $tempfile; then
    echo "ERROR DE EJECUCION..."
    cat $tempfile
    rm -rf $OBT/p${i}so.txt $tempfile
  else 
    ./comparefiles $OBT/p${i}so.txt $SAL/p${i}s.txt
    if [ $? -ne 0 ]; then
      p1tmp=`mktemp /tmp/prog2ii-diffp1XXXXX`
      p2tmp=`mktemp /tmp/prog2ii-diffp2XXXXX`
      sed 's/---*/--------/g' $OBT/p${i}so.txt > $p1tmp
      sed 's/---*/--------/g' $SAL/p${i}s.txt > $p2tmp
      
      diff -EwB $p1tmp $p2tmp 2>&1
      rm -f $p1tmp $p2tmp
    else
      # En la prueba 24 y 48 hay que comparar el playlist guardado como XSPF
      # En las pruebas 24, 31, 37 y 48 hay que comparar el playlist guardado como XSPF
      if [ $i -eq 24 -o $i -eq 31 -o $i -eq 37 -o $i -eq 48 ]; then
        ./comparefiles $OBT/p${i}so.xspf $SAL/p${i}s.xspf
        if [ $? -ne 0 ]; then
          echo "Playlist mal guardada en el fichero p${i}so.xspf"
          diff -EwB $OBT/p24so.xspf $SAL/p24s.xspf
        else 
          pruebaok $i
        fi;
      else
        # Para el resto de pruebas
        pruebaok $i
      fi;
    fi;
  fi;
  echo "--------------------------"
  done

  if [ $pok -eq $npruebas ]; then
    if [ $npruebas -eq 0 ]; then
    	echo -e "\nSE HAN OMITIDO LAS PRUEBAS DEL AUTOCORRECTOR\n"
    else 
    	echo -e "\nTODAS LAS PRUEBAS DEL AUTOCORRECTOR FUNCIONAN\n"
    fi;
  else 
  echo -e "\nOJO: FALLAN" $[npruebas-pok] "PRUEBAS DEL AUTOCORRECTOR\n"
  fi;



  echo "*********************************************************"
  echo " Ejecutando las pruebas unitarias..."
  echo "*********************************************************"

  # Copia el fichero binario
  cp entrada/minitunes.dat minitunes.dat
  

  if test -s ./p2TestRunner ; then
     tempfile=`mktemp /tmp/prog2iiXXXXX`
     tempfile2=`mktemp /tmp/prog2iiXXXXX`

     ./mata $MAXTIME $tempfile2 ./p2TestRunner < test/entrada-testAC.txt > $tempfile2 2> $tempfile
     sgr=$(grep "\.OK\!$" $tempfile)
     if test "$sgr" != "" ; then
       echo -e "\nTODAS LAS PRUEBAS UNITARIAS DEL AUTOCORRECTOR FUNCIONAN\n"
       nota=`echo - | awk -v K=$nota -v M=$valorpua '{printf("%.12g",K+M)}'` 
     else
       echo -e "\nFALLA ALGUNA PRUEBA UNITARIA DEL AUTOCORRECTOR:\n"
       cat $tempfile
       
       notapercentagepua=`echo - | tail -10 $tempfile | grep "Success rate" | awk '{gsub("Success rate: ",""); gsub("%",""); print;}'`
       notapua=$(echo "$notapercentagepua*$valorpua/100.0" | bc -l)
       nota=`echo - | awk -v K=$nota -v M=$notapua '{printf("%.12g",K+M)}'`
       
       echo 
     fi
     
     rm -r $tempfile
     rm -r $tempfile2
     
  else 
  	echo "NO COMPILAN LAS PRUEBAS UNITARIAS DEL AUTOCORRECTOR"
  fi;
  

  if test -s ./p2TestRunnerC ; then
     tempfile=`mktemp /tmp/prog2iiXXXXX`
     tempfile2=`mktemp /tmp/prog2iiXXXXX`

     ./mata $MAXTIME $tempfile2 ./p2TestRunnerC < test/entrada-testC.txt > $tempfile2 2> $tempfile
     sgr=$(grep "\.OK\!$" $tempfile)

     if test "$sgr" != "" ; then
       echo -e "\nTODAS LAS PRUEBAS UNITARIAS DEL CORRECTOR FUNCIONAN\n"
       nota=`echo - | awk -v K=$nota -v M=$valorpuc '{printf("%.12g",K+M)}'` 
     else
       echo -e "\nFALLA ALGUNA PRUEBA UNITARIA DEL CORRECTOR:\n"
       cat $tempfile
       
       notapercentagepuc=`echo - | tail -10 $tempfile | grep "Success rate" | awk '{gsub("Success rate: ",""); gsub("%",""); print;}'`
       notapuc=$(echo "$notapercentagepuc*$valorpuc/100.0" | bc -l)
       nota=`echo - | awk -v K=$nota -v M=$notapuc '{printf("%.12g",K+M)}'`
       
       echo 
     fi
     
     rm -r $tempfile
     rm -r $tempfile2
     
  else 
  	echo "NO COMPILAN LAS PRUEBAS UNITARIAS DEL CORRECTOR"
  fi;

  # Borra el fichero binario
  rm -rf minitunes.dat

  # Borra el player
  rm src/Player.*

fi;

echo "**********************************************************"
echo " Nota final..."
echo "**********************************************************"
echo $nota
