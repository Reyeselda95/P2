#include "Player.h"


// Funcion para reproducir una cancion. Necesita una URL como parámetro.
void Player::playSong(string url)
{
  if (url!="")
  {
  	playing = true;
    cout << "Reproduciendo " << url << endl;
  }
  else cout << "No URL for this song" << endl;
}

// Funcion para pausar o quitar la pausa a una cancion
void Player::pauseResumeSong()
{
  playing = !playing;
  if (playing)
    cout << "Se ha reanudado la reproduccion" << endl;
  else
    cout << "Se ha pausado la reproduccion" << endl; 
}

// Destructor (equivalente a endPlayer en pr2)
Player::~Player()
{
  playing = false;
  cout << "Se ha detenido el reproductor" << endl;
}


